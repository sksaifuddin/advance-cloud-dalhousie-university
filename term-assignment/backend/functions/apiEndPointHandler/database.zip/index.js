const { conn:db } = require('./database');
const { v4: uuid } = require("uuid");

exports.handler = async (event) => {
    console.log('event', event);
    // const res =  await testConnection();
    
    const { method, path } = event.requestContext.http;
    let {body} = event;
    const { user, tableName } = getTableNameAndUserFromPath(path);
    const userTableName = `${tableName}_${user}`;
    let res;
    switch(method) {
      case 'POST': {
        res = await postApiHandler(body, userTableName);
        break;
      };
      case 'GET': {
        console.log('in get');
        res = await getApiHandler(userTableName);
        break;
      }
      case 'PUT': {
        console.log('in put');
        break;
      }
      case 'DELETE': {
        console.log('in delete');
        break;
      }
    }
    console.log('res', JSON.parse(JSON.stringify(res)));
    const response = {
      statusCode: 200,
      body: JSON.stringify({
        data: JSON.parse(JSON.stringify(res))
      }),
    };
    return response;
  };
  
  const getTableNameAndUserFromPath = (path) => {
      const [_, id, tableName] = path.split('/');
      return { user: id, tableName };
  }
  
  
  const postApiHandler = (body, tableName) => {
      return new Promise((resolve, reject) => {
        const requestData = JSON.parse(body);
        requestData.id = uuid();
        const sqlQuery = `INSERT INTO ${tableName} (${Object.keys(requestData).join(', ')}) VALUES (${Object.values(
          requestData
        ).map((value) => (typeof value === 'string' ? `'${value}'` : value)).join(', ')})`;
        console.log('sql query', sqlQuery);
        db.query(sqlQuery, (err, result) => {
           if(err){
            reject(err);
           }
           console.log('result-->', result);
           resolve(result);
        })
      })
  }
  
  const getApiHandler = (tableName) => {
      return new Promise((resolve, reject) => {
          const sqlQuery = `SELECT * FROM ${tableName}`;
          db.query(sqlQuery, (err, result) => {
            if(err) { reject(err) };
            resolve(result);
          })
      })
  }

  const putApiHandler = () => {

  }


  const deleteApiHandler = () => {

  }
  
  const testConnection = () => {
    return new Promise((resolve, reject) => {
        db.query(`SELECT * FROM user`, (err, result) => {
            if(err) {reject(err)};
            resolve(result);
        })
    })
}